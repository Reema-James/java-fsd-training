//4. Implement Array List and add, remove, elements in the Array List and perform sorting of the elements using the iterator.

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListEx {
	public static void main(String[] args)
	{
		ArrayList<String>list=new ArrayList<String>();
		list.add("Volkswagen");
		list.add("Toyota");
		list.add("Audi");
		list.add("Mercedez");
		list.add("BMW");
		list.add("Hyundai");
		System.out.println("The elements in ArrayLists are: "+list);
		list.remove(5);
		System.out.println("The contents of list after removing the element at 5th position is: "+list);
		Collections.sort(list);
		System.out.println("After sorting the list: "+list);
	}

}