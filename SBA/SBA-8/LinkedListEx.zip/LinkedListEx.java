//5. Implement LinkedList and add, remove, elements in the LinkedList and perform sorting of the elements using the iterator.

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListEx {
	public static void main(String[] args)
	{
		LinkedList<String>list=new LinkedList<String>();
		list.add("Red");
		list.add("Italy");
		list.add("Blue");
		list.add("London");
		list.add("Paris");
		System.out.println("Linkedlist: "+list);
		list.remove(2);
		System.out.println("Linkedlist after deletion: "+list);
		


		 Iterator<String> it = list.iterator();


		    while(it.hasNext()) {
		    	  System.out.println(it.next());
		    	}
		    Collections.sort(list);
		    System.out.println(list);
	}

}